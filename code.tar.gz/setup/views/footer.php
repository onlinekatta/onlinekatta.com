					</div>
				</div>
				<div class="row footer-links">
					<ul class="list-group list-inline">
						<li><a target="_blank" href="http://tastyigniter.com"><?php echo lang('text_tastyigniter_home'); ?></a></li>
						<li><a target="_blank" href="http://docs.tastyigniter.com"><?php echo lang('text_documentation'); ?></a></li>
						<li><a target="_blank" href="http://forum.tastyigniter.com"><?php echo lang('text_community_forums'); ?></a></li>
						<li><a target="_blank" href="http://forum.tastyigniter.com/forum-21.html"><?php echo lang('text_feature_request'); ?></a></li>
					</ul>
				</div>
			</div>
		</div>
	</div>
</body>
</html>